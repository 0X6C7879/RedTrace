import { Store, ACTIVE_NODE_SQL } from './store.ts'
import path from 'node:path'
import { HttpError } from './types.ts'
import type { EngineConfig, Goal, Run, RunStatus, Worker, Step } from './types.ts'
import type { Operations } from './operations.ts'

export interface ExploreNotice { stepId: string; message: string; sourceIds?: string[] }
export interface ExploreNoticeResult { ok: boolean; status: 'queued' | 'duplicate' | 'rejected' | 'failed'; reason?: string; notificationId?: string; stepId?: string; runId?: string; sessionId?: string }
export interface TaskContext { store: Store; run: Run; worker: Worker; config: EngineConfig; signal: AbortSignal; operations?: Operations; currentMaxSteps?: () => number | null; featureAvailable?: (id: string) => boolean; taskPluginAllowed?: (id: string) => boolean; notifyExplore?: (notice: ExploreNotice) => ExploreNoticeResult }
export type RunTask = (context: TaskContext) => Promise<void>
export type SelectWorker = (worker: Worker, activity: Run['activity'], step?: Step) => Worker | undefined
type Active = { run: Run; abort: AbortController; completion: Promise<void> }

export class Scheduler {
  maintenance = false
  private readonly store: Store
  private readonly execute: RunTask
  private config: EngineConfig
  private running = new Map<string, Active>()
  private scheduled = false
  private closed = true
  private retryTimer?: ReturnType<typeof setTimeout>
  private cursor = 0
  private readonly changed = () => this.wake()
  private readonly selectWorker: SelectWorker
  private readonly criticalEnabled: () => boolean
  constructor(store: Store, config: EngineConfig, execute: RunTask, selectWorker: SelectWorker = worker => worker, criticalEnabled: () => boolean = () => true) { this.store = store; this.config = config; this.execute = execute; this.selectWorker = selectWorker; this.criticalEnabled = criticalEnabled }
  start() {
    if (!this.closed) return
    this.closed = false; this.store.recover(); this.store.changes.on('change', this.changed); this.wake()
  }
  update(config: EngineConfig) { this.config = config; this.wake() }
  get activeRuns() { return this.store.runsByStatus('running') }
  wake() {
    if (this.closed || this.scheduled) return
    this.scheduled = true
    queueMicrotask(() => { this.scheduled = false; if (!this.closed) this.dispatch() })
  }
  private select(activity: Run['activity'], resume?: Run, step?: Step, active = this.activeRuns): Worker | undefined {
    const count = (name: string) => active.filter(r => r.worker === name).length
    return this.config.workers.map(w => this.selectWorker(w, activity, step)).filter((w): w is Worker => !!w && w.enabled && this.eligible(w, activity, step) && (!resume || (w.name === resume.worker && w.backend === resume.backend)) && count(w.name) < w.maxRunning)
      .sort((a, b) => a.priority - b.priority || count(a.name) - count(b.name) || a.name.localeCompare(b.name))[0]
  }
  /** Decide needs a `reason` worker; an Execute run carries the Step it claims,
   * so a bootstrap Step only ever reaches a `bootstrap` worker and an ordinary
   * Step only ever reaches an `explore` worker. */
  private eligible(worker: Worker, activity: Run['activity'], step?: Step): boolean {
    if (activity === 'decide') return worker.reason
    return step?.bootstrap ? worker.bootstrap : worker.explore
  }
  private dispatch() {
    if (this.maintenance) return
    if (this.retryTimer) { clearTimeout(this.retryTimer); this.retryTimer = undefined }
    for (const task of this.running.values()) {
      try {
        const project = this.store.project(task.run.projectId)
        const step = task.run.stepId ? this.store.node<Step>(task.run.projectId, task.run.stepId, 'step') : undefined
        const goalOpen = !step || this.store.node<Goal>(task.run.projectId, step.goalId, 'goal').status === 'open'
        if (this.store.run(task.run.id).status !== 'running' || (project.status !== 'active' && !(project.status === 'completed' && task.run.activity === 'decide')) || ['cancelled', 'parked'].includes(step?.status ?? '') || !goalOpen) task.abort.abort('Project or Step stopped')
      } catch (reason) { if (reason instanceof HttpError && reason.status === 404) task.abort.abort('Project deleted'); else throw reason }
    }
    const activeRuns = this.activeRuns
    const launch = (run: Run, worker: Worker) => { activeRuns.push(run); this.launch(run,worker) }
    const projects = this.store.projects().filter(p => p.status === 'active')
    if (!projects.length) return
    let retryAt = Infinity, madeProgress = true
    while (madeProgress && activeRuns.length < this.config.maxWorkers) {
      madeProgress = false
      for (const planningOnly of [true, false]) {
        for (let i = 0; i < projects.length && activeRuns.length < this.config.maxWorkers; i++) {
          const project = projects[(this.cursor + i) % projects.length]
          const active = activeRuns
          if (active.filter(r => r.projectId === project.id).length >= this.config.maxProjectWorkers) continue
          if (!active.some(r => r.projectId === project.id) && new Set(active.map(r => r.projectId)).size >= this.config.maxRunningProjects) continue
          const p = this.store.project(project.id)
          if (p.status !== 'active') continue
          const nodes = this.store.db.prepare(`SELECT data FROM nodes WHERE project_id=? AND ${ACTIVE_NODE_SQL}
            AND (kind='goal' OR (kind='step' AND (json_extract(data,'$.status') IN ('pending','paused') OR json_extract(data,'$.bootstrap')=1)))`)
            .all(p.id).map(row => JSON.parse(String(row.data)) as Step | Goal)
          const steps = nodes.filter((node): node is Step => node.kind === 'step')
          const goals = new Map(nodes.filter(node => node.kind === 'goal').map(goal => [goal.id, goal]))
          // Bootstrap is a strict project gate, not merely the first runnable
          // Step. Reason may start only after that Step succeeded with a Fact.
          // A failed/cancelled/empty Bootstrap remains visible for diagnosis and
          // can be retried explicitly without planning from an uninitialized graph.
          const bootstrap = steps.find(s => s.bootstrap)
          const bootstrapComplete = !p.bootstrap || !!bootstrap && bootstrap.status === 'done' && bootstrap.factIds.length > 0
          const pendingEvidence = (p.evidenceSeq ?? p.factSeq) > (p.acknowledgedEvidenceSeq ?? p.acknowledgedFactSeq)
          const pendingCritical = this.criticalEnabled() && (p.criticalSeq ?? 0) > (p.acknowledgedCriticalSeq ?? 0)
          const pendingHint = (p.hintSeq ?? 0) > (p.acknowledgedHintSeq ?? 0)
          const needsDecide = bootstrapComplete && (p.initialPlanningPending || p.planningRetryPending || pendingEvidence || pendingCritical || pendingHint)
            && !active.some(r => r.projectId === p.id && r.activity === 'decide')
          if (planningOnly && needsDecide) {
            if (p.retryAfter > Date.now()) retryAt = Math.min(retryAt, p.retryAfter)
            else {
              const worker = this.select('decide',undefined,undefined,activeRuns)
              if (worker) { launch(this.store.claim(p.id, 'decide', worker), worker); madeProgress = true; continue }
            }
          }
          if (planningOnly) continue
          // An unavailable Decide never prevents existing execution work from starting.
          const runnable = steps.filter(s => !s.replacementPending && ['pending', 'paused'].includes(s.status) && goals.get(s.goalId)?.status === 'open')
            .sort((a, b) => b.priority - a.priority || a.createdAt.localeCompare(b.createdAt) || a.id.localeCompare(b.id))
          for (const step of runnable) {
            const paused = step.status === 'paused' ? this.store.runsByStatus('paused', p.id).find(r => r.stepId === step.id) : undefined
            const worker = this.select('execute',paused,step,activeRuns)
            if (!worker) continue
            launch(this.store.claim(p.id, 'execute', worker, step.id), worker); madeProgress = true; break
          }
        }
      }
      this.cursor = (this.cursor + 1) % projects.length
    }
    if (Number.isFinite(retryAt)) this.retryTimer = setTimeout(() => this.wake(), Math.max(1, retryAt - Date.now()))
  }
  private launch(run: Run, worker: Worker) {
    const abort = new AbortController(), config = structuredClone(this.config)
    run.provider = worker.provider; run.model = worker.model; run.workspaceRoot = path.join(config.workspaceRoot, run.projectId)
    this.store.transaction(() => this.store.saveRun(run))
    const task: Active = { run, abort, completion: Promise.resolve() }
    this.running.set(run.id, task)
    task.completion = (async () => {
      let status: RunStatus = 'succeeded', error: string | null = null
      try { await this.execute({ store: this.store, run, worker: structuredClone(worker), config, signal: abort.signal }) }
      catch (reason) { status = 'failed'; error = reason instanceof Error ? reason.message : String(reason) }
      finally {
        try {
          if (abort.signal.aborted) {
            const project = this.store.project(run.projectId)
            status = (this.closed || project.status === 'stopped') && run.activity === 'execute' ? 'paused' : 'cancelled'
            error = null
            if (this.store.run(run.id).pendingTools.length) { status = 'unknown'; error = 'Activity stopped with an unconfirmed tool result; verify before retrying' }
          }
          this.store.finishRun(run.id, status, error)
          // Deleting a project mid-abort cascades its runs away; there is nothing left to finish.
        } catch (reason) { if (!(reason instanceof HttpError && reason.status === 404)) throw reason }
        finally { this.running.delete(run.id); this.wake() }
      }
    })()
  }
  async close() {
    this.closed = true
    this.store.changes.off('change', this.changed)
    if (this.retryTimer) clearTimeout(this.retryTimer)
    for (const task of this.running.values()) task.abort.abort('Engine shutting down')
    await Promise.all([...this.running.values()].map(t => t.completion))
  }
}
