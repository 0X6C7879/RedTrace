function operationsPage() {
  return {
    active: false,
    initialized: false,
    loading: false,
    refreshing: false,
    error: '',
    pageMode: 'webshell',
    tab: 'resources',
    resourceKind: 'all',
    query: '',
    resources: [],
    tasks: [],
    audit: [],
    summary: { resources: {}, tasks: {} },
    selectedResourceId: '',
    detail: null,
    terminalOutput: '',
    terminalHistory: [],
    terminalIdentity: { user: 'www-data', host: 'target', cwd: '/var/www/html' },
    command: '',
    workspaceTab: 'terminal',
    terminalSessionId: 'terminal-1',
    terminalSessionName: '终端 1',
    pathInput: '/',
    fileContent: '',
    fileDirectoryPath: '/',
    fileEntries: [],
    fileLoading: false,
    fileMessage: '',
    selectedFilePath: '',
    fileEditorOpen: false,
    fileEditorPath: '',
    fileContextMenu: { open: false, x: 0, y: 0, entry: null },
    fileDialog: { open: false, mode: '', value: '', entry: null },
    databaseType: 'mysql',
    databaseHost: '127.0.0.1',
    databasePort: '3306',
    databaseName: '',
    databaseUser: '',
    databasePassword: '',
    databaseQuery: 'SELECT version();',
    runningAction: false,
    resultLoading: false,
    showCreate: false,
    showSecret: false,
    secretOnce: '',
    createBusy: false,
    testBusy: false,
    testMessage: '',
    createError: '',
    createForm: {},
    payloadListenerId: '',
    payloadKind: 'curl_beacon',
    payloadCallback: '',
    payloadOneliner: '',
    payloadGenerating: false,
    payloadOs: 'linux',
    payloadArch: 'amd64',
    payloadBuilding: false,
    builtPayload: null,
    externalPayloadFormat: 'default',
    externalPayloadOptions: '{}',
    externalPayloadBuilding: false,
    payloadMenuOpen: false,
    payloadDialogMode: '',
    payloadUploadFile: null,
    payloadUploadName: '',
    payloadUploadSummary: '',
    payloadUploadBusy: false,
    payloadCopiedId: '',
    taskStatusFilter: 'all',
    eventStatusFilter: 'all',
    pollTimer: null,
    lastProjectId: '',
    kindOptions: [
      { value: 'all', label: '全部资源' },
      { value: 'webshell', label: 'WebShell' },
      { value: 'c2_listener', label: 'C2 Listener' },
      { value: 'c2_session', label: 'C2 Session' },
      { value: 'c2_payload', label: 'C2 Payload' },
      { value: 'c2_profile', label: '流量伪装' },
      { value: 'proxy', label: '代理通道' },
      { value: 'file', label: '文件' },
      { value: 'credential_ref', label: '凭据引用' },
      { value: 'result', label: '任务结果' },
    ],

    init() {
      this.resetCreateForm();
      this.pollTimer = window.setInterval(() => {
        if (this.active && this.projectId()) this.refresh(false);
      }, 3000);
      window.addEventListener('beforeunload', () => window.clearInterval(this.pollTimer), { once: true });
    },

    activePages() {
      return [
        'webshell',
        'c2-listeners',
        'c2-sessions',
        'c2-tasks',
        'c2-payloads',
        'c2-events',
        'c2-profiles',
        'c2-credentials',
      ];
    },

    pageTitle() {
      return {
        webshell: 'WebShell 管理',
        'c2-listeners': '监听器管理',
        'c2-sessions': '会话管理',
        'c2-tasks': 'C2 任务',
        'c2-payloads': 'Payload 管理',
        'c2-events': 'C2 事件',
        'c2-profiles': '流量伪装 / Malleable Profile',
        'c2-credentials': '凭证',
      }[this.pageMode] || 'WebShell 管理';
    },

    pageBadge() {
      return this.pageMode.startsWith('c2-') ? 'C2 · 全局共享' : '全局共享';
    },

    pageDescription() {
      return {
        webshell: '所有任务共享连接；保留来源项目、Intent 与 Worker 标记',
        'c2-listeners': '全局 reverse / bind / Beacon / 外部 C2 Listener，独立于 Worker 生命周期',
        'c2-sessions': '所有任务共享 reverse、bind、SSH、WinRM、PsExec、WMI 与 Beacon 会话',
        'c2-tasks': '跨 Worker 的异步任务队列、审批、取消与结果引用',
        'c2-payloads': 'Worker、生成器与人工上传的载荷统一留存、共享和下载',
        'c2-events': '统一查看 C2 Session、任务和人工接管事件',
        'c2-profiles': '配置 User-Agent、Beacon URI、Jitter 和响应头',
        'c2-credentials': '集中保存主机、Web、数据库、云与 Active Directory 凭证',
      }[this.pageMode] || '';
    },

    modeKind() {
      return {
        webshell: 'webshell',
        'c2-listeners': 'c2_listener',
        'c2-sessions': 'c2_session',
        'c2-tasks': 'c2_session',
        'c2-payloads': 'c2_payload',
        'c2-events': 'c2_session',
        'c2-profiles': 'c2_profile',
        'c2-credentials': 'credential_ref',
      }[this.pageMode] || 'webshell';
    },

    defaultCreateKind() {
      return this.modeKind();
    },

    isDedicatedLedgerPage() {
      return ['c2-tasks', 'c2-events'].includes(this.pageMode);
    },

    canCreateForPage() {
      return ['webshell', 'c2-listeners', 'c2-sessions', 'c2-profiles', 'c2-credentials'].includes(this.pageMode);
    },

    createButtonLabel() {
      return {
        webshell: '添加连接',
        'c2-listeners': '创建监听器',
        'c2-sessions': '新建会话',
        'c2-payloads': '生成 Payload',
        'c2-profiles': '创建 Profile',
        'c2-credentials': '保存凭证',
      }[this.pageMode] || '添加';
    },

    listLabel() {
      return {
        webshell: '连接列表',
        'c2-listeners': '监听器列表',
        'c2-sessions': '会话列表',
        'c2-tasks': '按会话查看任务',
        'c2-payloads': 'Payload 列表',
        'c2-events': '按会话查看事件',
        'c2-profiles': '配置列表',
        'c2-credentials': '凭证列表',
      }[this.pageMode] || '列表';
    },

    projectId() {
      // Operations resources are project-agnostic: when no RedTrace task is
      // active, address the global pool via the ``_global`` sentinel so the
      // list view, summary, audit and single-resource queries stay usable.
      return this.selectedProjectId || '_global';
    },

    isGlobalScope() {
      return !this.selectedProjectId;
    },

    projectName() {
      const project = (this.projects || []).find((item) => item.id === this.projectId());
      return project?.title || project?.name || this.projectId() || '选择项目';
    },

    setActive(active, projectId, pageMode) {
      this.active = Boolean(active);
      if (!this.active) return;
      const pageChanged = pageMode && pageMode !== this.pageMode;
      if (pageMode) this.pageMode = pageMode;
      if (pageChanged) {
        this.selectedResourceId = '';
        this.detail = null;
        this.query = '';
        this.tab = pageMode === 'c2-events' ? 'audit' : 'resources';
      }
      const scopedProjectId = projectId || '_global';
      if (scopedProjectId !== this.lastProjectId || !this.initialized || pageChanged) {
        this.lastProjectId = scopedProjectId;
        queueMicrotask(() => { if (this.active) void this.refresh(true); });
      }
    },

    async api(path, options = {}) {
      const contentType = options.body instanceof Blob ? 'application/octet-stream' : 'application/json';
      const response = await fetch(path, {
        ...options,
        headers: { 'Content-Type': contentType, ...(options.headers || {}) },
      });
      if (!response.ok) {
        let message = `${response.status} ${response.statusText}`;
        try {
          const body = await response.json();
          message = body.detail || message;
        } catch (_) {}
        throw new Error(message);
      }
      if (response.status === 204) return null;
      const responseType = response.headers.get('content-type') || '';
      return responseType.includes('application/json') ? response.json() : response.text();
    },

    async refresh(showLoading = true) {
      const projectId = this.projectId();
      if (!projectId || this.refreshing) return;
      const pageMode = this.pageMode;
      this.refreshing = true;
      this.loading = showLoading;
      this.error = '';
      try {
        const responses = await Promise.allSettled([
          this.api(`/projects/${encodeURIComponent(projectId)}/resources?limit=500`),
          this.api(`/projects/${encodeURIComponent(projectId)}/operations/tasks?limit=200`),
          this.api(`/projects/${encodeURIComponent(projectId)}/operations/audit?limit=200`),
          this.api(`/projects/${encodeURIComponent(projectId)}/operations/summary`),
        ]);
        const failed = responses.find(response => response.status === 'rejected');
        if (failed) throw failed.reason;
        const [resourceData, taskData, auditData, summaryData] = responses.map(response => response.value);
        if (!this.active || projectId !== this.projectId() || pageMode !== this.pageMode) return;
        this.resources = resourceData.resources || [];
        if (!this.payloadListenerId) {
          this.payloadListenerId = this.resources.find((item) => item.kind === 'c2_listener')?.id || '';
        }
        this.tasks = taskData.tasks || [];
        this.audit = auditData.events || [];
        this.summary = summaryData;
        if (this.selectedResourceId) {
          const current = this.resources.find((item) => item.id === this.selectedResourceId);
          if (!current) {
            this.selectedResourceId = '';
            this.detail = null;
          } else {
            this.detail = { ...(this.detail || {}), resource: current };
          }
        }
        if (!this.isDedicatedLedgerPage() && !this.selectedResourceId && this.filteredResources().length) {
          await this.selectResource(this.filteredResources()[0].id);
        }
        this.initialized = true;
      } catch (error) {
        if (this.active && projectId === this.projectId() && pageMode === this.pageMode) this.error = error.message;
      } finally {
        this.refreshing = false;
        this.loading = false;
        if (this.active && (projectId !== this.projectId() || pageMode !== this.pageMode)) void this.refresh(true);
      }
    },

    filteredResources() {
      const needle = this.query.trim().toLowerCase();
      return this.resources.filter((item) => {
        if (item.kind !== this.modeKind()) return false;
        if (!needle) return true;
        return [item.name, item.target, item.summary, item.id]
          .some((value) => String(value || '').toLowerCase().includes(needle));
      });
    },

    async selectResource(id) {
      if (!id || !this.projectId()) return;
      const projectId = this.projectId(), pageMode = this.pageMode;
      const changed = id !== this.selectedResourceId;
      this.selectedResourceId = id;
      this.resultLoading = true;
      try {
        const detail = await this.api(
          `/projects/${encodeURIComponent(projectId)}/resources/${encodeURIComponent(id)}`
        );
        if (!this.active || projectId !== this.projectId() || pageMode !== this.pageMode || id !== this.selectedResourceId) return;
        this.detail = detail;
        const resource = this.detail.resource;
        const latest = (this.detail.tasks || []).find((task) => task.output_summary);
        if (resource.kind === 'webshell' && changed) this.resetWebshellWorkspace(resource);
        if (resource.kind === 'c2_session' && changed) {
          this.terminalIdentity = {
            user: resource.metadata?.username || 'shell',
            host: resource.metadata?.hostname || resource.target || 'target',
            cwd: resource.metadata?.cwd || (String(resource.metadata?.os || '').toLowerCase() === 'windows' ? 'C:\\' : '/'),
          };
          this.terminalHistory = [];
        }
        if (resource.kind !== 'webshell' && (changed || latest)) this.terminalOutput = latest?.output_summary || '';
      } catch (error) {
        if (this.active && projectId === this.projectId() && pageMode === this.pageMode && id === this.selectedResourceId) this.error = error.message;
      } finally {
        if (projectId === this.projectId() && pageMode === this.pageMode && id === this.selectedResourceId) this.resultLoading = false;
      }
    },

    currentResource() {
      return this.detail?.resource || this.resources.find((item) => item.id === this.selectedResourceId) || null;
    },

    webshellUsable() {
      const resource = this.currentResource();
      return resource?.kind === 'webshell' && resource.status === 'available';
    },

    webshellSessionLabel() {
      if (this.runningAction) return '命令执行中';
      return this.webshellUsable()
        ? '会话可用'
        : `会话${this.statusLabel(this.currentResource()?.status || 'offline')}`;
    },

    resetWebshellWorkspace(resource) {
      let host = 'target';
      try {
        host = new URL(resource.target).hostname || host;
      } catch (_) {
        host = String(resource.target || '').split(/[/:]/).filter(Boolean)[0] || host;
      }
      const windows = String(resource.metadata?.os || '').toLowerCase() === 'windows';
      this.terminalIdentity = {
        user: resource.metadata?.username || (windows ? 'iis apppool' : 'www-data'),
        host: resource.metadata?.hostname || host,
        cwd: resource.metadata?.cwd || (windows ? 'C:\\inetpub\\wwwroot' : '/var/www/html'),
      };
      this.terminalHistory = [];
      this.workspaceTab = 'terminal';
      this.fileDirectoryPath = resource.metadata?.cwd || (windows ? 'C:\\inetpub\\wwwroot' : '/var/www/html');
      this.pathInput = this.fileDirectoryPath;
      this.fileEntries = [];
      this.fileMessage = '';
      this.fileEditorOpen = false;
      this.selectedFilePath = '';
      this.closeFileContextMenu();
    },

    terminalPrompt() {
      const { user, cwd } = this.terminalIdentity;
      return `(${user}:${cwd}) $`;
    },

    tasksForCurrent() {
      if (this.pageMode === 'c2-tasks') {
        const sessionIds = new Set(this.resources.filter((item) => item.kind === 'c2_session').map((item) => item.id));
        return this.tasks.filter((task) => sessionIds.has(task.resource_id));
      }
      if (!this.selectedResourceId) return [];
      return this.tasks.filter((task) => task.resource_id === this.selectedResourceId);
    },

    resourceForId(resourceId) {
      return this.resources.find((item) => item.id === resourceId) || null;
    },

    c2Tasks() {
      const sessionIds = new Set(
        this.resources.filter((item) => item.kind === 'c2_session').map((item) => item.id)
      );
      const needle = this.query.trim().toLowerCase();
      return this.tasks.filter((task) => {
        if (!sessionIds.has(task.resource_id)) return false;
        if (this.taskStatusFilter !== 'all' && task.status !== this.taskStatusFilter) return false;
        if (!needle) return true;
        const resource = this.resourceForId(task.resource_id);
        return [
          task.id,
          task.action,
          task.actor,
          task.output_summary,
          resource?.name,
          resource?.target,
        ].some((value) => String(value || '').toLowerCase().includes(needle));
      });
    },

    c2TaskCount(statuses) {
      const wanted = Array.isArray(statuses) ? statuses : [statuses];
      return this.tasks.filter((task) => {
        const resource = this.resourceForId(task.resource_id);
        return resource?.kind === 'c2_session' && wanted.includes(task.status);
      }).length;
    },

    taskRiskLabel(risk) {
      return {
        low: '低风险',
        medium: '中风险',
        high: '高风险',
        critical: '关键风险',
      }[risk] || risk || '未标记';
    },

    taskInputSummary(task) {
      const input = task?.input || {};
      const keys = Object.keys(input);
      if (!keys.length) return '无输入参数';
      return keys.slice(0, 3).map((key) => `${key}=${String(input[key])}`).join(' · ');
    },

    visibleAudit() {
      if (this.pageMode === 'c2-events') {
        const c2Ids = new Set(
          this.resources
            .filter((item) => ['c2_listener', 'c2_session', 'c2_payload', 'c2_profile'].includes(item.kind))
            .map((item) => item.id)
        );
        return this.audit.filter((item) => !item.resource_id || c2Ids.has(item.resource_id));
      }
      if (!this.selectedResourceId) return this.audit;
      return this.audit.filter((item) => item.resource_id === this.selectedResourceId);
    },

    isC2AuditEvent(event) {
      if (String(event.action || '').startsWith('c2.')) return true;
      const resource = this.resourceForId(event.resource_id);
      if (resource && String(resource.kind || '').startsWith('c2_')) return true;
      const task = this.tasks.find((item) => item.id === event.task_id);
      return Boolean(task && this.resourceForId(task.resource_id)?.kind === 'c2_session');
    },

    c2Events() {
      const needle = this.query.trim().toLowerCase();
      return this.audit.filter((event) => {
        if (!this.isC2AuditEvent(event)) return false;
        if (this.eventStatusFilter !== 'all' && event.status !== this.eventStatusFilter) return false;
        if (!needle) return true;
        const resource = this.resourceForId(event.resource_id);
        return [
          event.action,
          event.actor,
          event.status,
          event.task_id,
          event.detail?.summary,
          event.detail?.error,
          event.detail?.reason,
          resource?.name,
          resource?.target,
        ].some((value) => String(value || '').toLowerCase().includes(needle));
      });
    },

    c2EventCount(statuses = null) {
      const wanted = statuses == null ? null : (Array.isArray(statuses) ? statuses : [statuses]);
      return this.audit.filter((event) => this.isC2AuditEvent(event) && (!wanted || wanted.includes(event.status))).length;
    },

    c2EventActorCount() {
      return new Set(this.audit.filter((event) => this.isC2AuditEvent(event)).map((event) => `${event.actor_type}:${event.actor}`)).size;
    },

    eventCategory(event) {
      const action = String(event?.action || '');
      if (action.startsWith('operation.')) return '任务';
      if (action.startsWith('c2.session')) return '会话';
      if (action.startsWith('c2.listener')) return '监听器';
      if (action.startsWith('c2.payload')) return 'Payload';
      if (action.startsWith('resource.')) return '资源';
      return '系统';
    },

    eventDetailText(event) {
      const detail = event?.detail || {};
      return detail.summary || detail.error || detail.reason || detail.decision || '';
    },

    pendingApprovals() {
      return this.tasks.filter((task) => task.status === 'awaiting_approval').length;
    },

    activeTasks() {
      return this.tasks.filter((task) => ['queued', 'running', 'awaiting_approval'].includes(task.status)).length;
    },

    availableResources() {
      return this.filteredResources().filter((item) => this.resourceStatus(item) === 'available').length;
    },

    kindLabel(kind) {
      return this.kindOptions.find((item) => item.value === kind)?.label || kind;
    },

    resourceStatus(resource) {
      return resource?.kind === 'c2_session' && resource.status === 'available' && resource.metadata?.connection_type === 'direct' && resource.metadata?.runtime_verified !== true ? 'unverified' : resource?.status;
    },

    statusLabel(status) {
      return {
        available: '可用',
        unverified: '已登记 · 待验证',
        degraded: '异常',
        offline: '离线',
        retired: '已归档',
        queued: '等待执行',
        running: '执行中',
        awaiting_approval: '待审批',
        succeeded: '成功',
        failed: '失败',
        cancelled: '已取消',
        rejected: '已拒绝',
      }[status] || status;
    },

    statusClass(status) {
      return `ops-status-${String(status || 'offline').replaceAll('_', '-')}`;
    },

    relativeTime(value) {
      if (!value) return '—';
      const date = new Date(value);
      const seconds = Math.max(0, Math.floor((Date.now() - date.getTime()) / 1000));
      if (seconds < 60) return `${seconds} 秒前`;
      if (seconds < 3600) return `${Math.floor(seconds / 60)} 分钟前`;
      if (seconds < 86400) return `${Math.floor(seconds / 3600)} 小时前`;
      return date.toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
    },

    actorName() {
      return 'admin';
    },

    resetCreateForm(kind = 'webshell') {
      this.createForm = {
        kind,
        name: '',
        target: '',
        summary: '',
        status: 'available',
        commandParam: 'cmd',
        passwordParam: '',
        password: '',
        shellType: kind === 'c2_session' ? 'ssh' : 'php',
        protocol: 'auto',
        targetOs: 'auto',
        encoding: 'auto',
        method: 'POST',
        verifyTls: false,
        listenerType: 'http_beacon',
        bindHost: '127.0.0.1',
        bindPort: '8443',
        callbackHost: '',
        targetHost: '',
        profileId: '',
        profileName: '',
        userAgent: '',
        beaconUris: '/api/v1/status',
        jitterMin: 100,
        jitterMax: 500,
        responseHeaders: '{"Server":"nginx"}',
        endpoint: '',
        token: '',
        metadataJson: '{}',
        parentResourceId: '',
        credentialType: 'host',
        credentialUsername: '',
        credentialDomain: '',
        credentialSecret: '',
        sessionPort: '',
        sessionUsername: '',
        sessionDomain: '',
        sessionSecret: '',
        sessionSecretType: 'password',
      };
      this.createError = '';
      this.testMessage = '';
      this.secretOnce = '';
    },

    openCreate(kind = 'webshell') {
      this.resetCreateForm(kind);
      this.showCreate = true;
    },

    async createResource() {
      if (!this.projectId()) return;
      if (this.createForm.kind === 'webshell' && !this.createForm.name.trim()) {
        this.createForm.name = this.createForm.target.trim();
      }
      if (this.createForm.kind === 'c2_listener' && !this.createForm.name.trim()) {
        this.createForm.name = `${this.createForm.listenerType}-${this.createForm.bindPort}`;
      }
      if (this.createForm.kind === 'c2_profile' && !this.createForm.name.trim()) {
        this.createForm.name = this.createForm.profileName.trim();
      }
      if (!this.createForm.name.trim()) return;
      this.createBusy = true;
      this.createError = '';
      const form = this.createForm;
      const metadata = {};
      const secret = {};
      if (form.kind === 'webshell') {
        metadata.command_param = form.commandParam || 'cmd';
        metadata.password_param = form.passwordParam || '';
        metadata.shell_type = form.shellType;
        metadata.protocol = form.protocol;
        metadata.os = form.targetOs;
        metadata.encoding = form.encoding;
        metadata.method = form.method;
        metadata.verify_tls = Boolean(form.verifyTls);
        if (form.password) secret.password = form.password;
      }
      if (form.kind === 'c2_listener') {
        metadata.listener_type = form.listenerType;
        metadata.bind_host = form.bindHost || '127.0.0.1';
        metadata.bind_port = Number(form.bindPort || 0);
        metadata.callback_host = form.callbackHost || '';
        metadata.target_host = form.targetHost || '';
        metadata.profile_id = form.profileId || '';
        if (form.listenerType === 'external_c2') {
          metadata.adapter_endpoint = form.endpoint || '';
          if (form.endpoint) secret.adapter_endpoint = form.endpoint;
          if (form.token) secret.token = form.token;
        }
        form.target = `${metadata.bind_host}:${metadata.bind_port}`;
        form.status = 'available';
      }
      if (form.kind === 'c2_session') {
        metadata.shell_type = form.shellType;
        metadata.connection_type = 'direct';
        metadata.username = form.sessionUsername || '';
        metadata.domain = form.sessionDomain || '';
        if (form.sessionPort) metadata.port = Number(form.sessionPort);
        if (form.sessionSecret) secret[form.sessionSecretType] = form.sessionSecret;
        form.status = 'available';
      }
      if (form.kind === 'c2_profile') {
        metadata.user_agent = form.userAgent || '';
        metadata.beacon_uris = String(form.beaconUris || '').split('\n').map((item) => item.trim()).filter(Boolean);
        metadata.jitter_min_ms = Number(form.jitterMin || 0);
        metadata.jitter_max_ms = Number(form.jitterMax || 0);
        try {
          metadata.response_headers = JSON.parse(form.responseHeaders || '{}');
        } catch (_) {
          this.createError = '响应头必须是有效 JSON';
          this.createBusy = false;
          return;
        }
        form.name = form.profileName || form.name;
        form.target = `profile://${form.name}`;
      }
      if (form.kind === 'credential_ref') {
        metadata.credential_type = form.credentialType;
        metadata.username = form.credentialUsername || '';
        metadata.domain = form.credentialDomain || '';
        if (form.credentialSecret) secret.value = form.credentialSecret;
      }
      try {
        const data = await this.api(`/projects/${encodeURIComponent(this.projectId())}/resources`, {
          method: 'POST',
          body: JSON.stringify({
            kind: form.kind,
            name: form.name.trim(),
            target: form.target.trim(),
            summary: form.summary.trim(),
            status: form.status,
            metadata,
            secret,
            parent_resource_id: form.parentResourceId || null,
            actor_type: 'human',
            actor: this.actorName(),
          }),
        });
        this.secretOnce = data.secret_once || '';
        this.showCreate = false;
        this.showSecret = Boolean(this.secretOnce);
        await this.refresh(false);
        await this.selectResource(data.resource.id);
      } catch (error) {
        this.createError = error.message;
      } finally {
        this.createBusy = false;
      }
    },

    async createTask(action, arguments = {}, risk = 'low', requiresApproval = false, options = {}) {
      const resource = this.currentResource();
      if (!resource || this.runningAction) return null;
      this.runningAction = true;
      this.error = '';
      try {
        const data = await this.api(
          `/projects/${encodeURIComponent(this.projectId())}/resources/${encodeURIComponent(resource.id)}/tasks`,
          {
            method: 'POST',
            body: JSON.stringify({
              action,
              arguments,
              actor_type: 'human',
              actor: this.actorName(),
              risk,
              requires_approval: requiresApproval,
            }),
          }
        );
        if (!options.silent) {
          this.terminalOutput = `任务 ${data.task.id} 已${data.task.status === 'awaiting_approval' ? '提交审批' : '进入队列'}。`;
        }
        await this.refresh(false);
        if (!options.silent) await this.selectResource(resource.id);
        return data.task;
      } catch (error) {
        this.error = error.message;
        if (!options.silent) this.terminalOutput = `操作失败：${error.message}`;
        return null;
      } finally {
        this.runningAction = false;
      }
    },

    async waitForTask(taskId, timeoutMs = 65000) {
      const started = Date.now();
      while (Date.now() - started < timeoutMs) {
        const data = await this.api(
          `/projects/${encodeURIComponent(this.projectId())}/operations/tasks/${encodeURIComponent(taskId)}`
        );
        const task = data.task;
        if (task && ['succeeded', 'failed', 'cancelled', 'rejected'].includes(task.status)) return task;
        await new Promise((resolve) => window.setTimeout(resolve, 350));
      }
      throw new Error('任务仍在后台执行，可在“任务”页继续查看');
    },

    async runCommand() {
      const value = this.command.trim();
      const resource = this.currentResource();
      const usableShell = resource?.status === 'available' && ['webshell', 'c2_session'].includes(resource.kind);
      if (!value || !usableShell) return;
      this.command = '';
      const record = {
        id: `${Date.now()}-${this.terminalHistory.length}`,
        prompt: this.terminalPrompt(),
        user: this.terminalIdentity.user,
        cwd: this.terminalIdentity.cwd,
        command: value,
        output: '正在执行…',
        failed: false,
      };
      const recordIndex = this.terminalHistory.length;
      this.terminalHistory.push(record);
      const queued = await this.createTask(
        'command',
        { command: resource.kind === 'webshell' ? this.terminalExecutionCommand(value) : value },
        'medium',
        false,
        { silent: true }
      );
      if (!queued || queued.status === 'awaiting_approval') return;
      this.runningAction = true;
      try {
        const completed = await this.waitForTask(queued.id);
        let output = completed.output_summary || this.statusLabel(completed.status);
        if (completed.result_ref) output = (await this.api(completed.result_ref, { headers: {} })) || output;
        const renderedOutput = String(output || '').replace(/\s+$/, '');
        this.terminalOutput = renderedOutput;
        this.terminalHistory[recordIndex] = {
          ...this.terminalHistory[recordIndex],
          output: renderedOutput,
          failed: completed.status !== 'succeeded',
        };
        this.updateTerminalContext(value, renderedOutput);
        await this.refresh(false);
      } catch (error) {
        this.terminalHistory[recordIndex] = {
          ...this.terminalHistory[recordIndex],
          output: error.message,
          failed: true,
        };
      } finally {
        this.runningAction = false;
      }
    },

    terminalExecutionCommand(value) {
      const windows = String(this.currentResource()?.metadata?.os || '').toLowerCase() === 'windows';
      const cwd = this.terminalIdentity.cwd;
      const cdMatch = value.match(/^cd(?:\s+(.+))?$/i);
      if (windows) {
        const prefix = `cd /d "${String(cwd).replaceAll('"', '""')}"`;
        return cdMatch
          ? `${prefix} && cd /d ${cdMatch[1] || 'C:\\'} && cd`
          : `${prefix} && ${value}`;
      }
      const quotedCwd = `'${String(cwd).replaceAll("'", "'\\''")}'`;
      return cdMatch
        ? `cd ${quotedCwd} && cd ${cdMatch[1] || '/'} && pwd`
        : `cd ${quotedCwd} && ${value}`;
    },

    updateTerminalContext(command, output) {
      const firstLine = String(output || '').split(/\r?\n/).find((line) => line.trim())?.trim();
      if (!firstLine) return;
      if (/^whoami$/i.test(command)) this.terminalIdentity.user = firstLine;
      if (/^hostname$/i.test(command)) this.terminalIdentity.host = firstLine;
      if (/^pwd$/i.test(command) || /^cd(?:\s|$)/i.test(command)) this.terminalIdentity.cwd = firstLine;
    },

    async runQuickCommand(command) {
      if (this.runningAction || !this.webshellUsable()) return;
      this.command = command;
      await this.runCommand();
    },

    clearTerminal() {
      this.terminalHistory = [];
    },

    async copyTerminal() {
      const log = this.terminalHistory
        .map((item) => `${item.prompt} ${item.command}\n${item.output}`)
        .join('\n');
      await navigator.clipboard.writeText(`${log}${log ? '\n' : ''}${this.terminalPrompt()} `);
    },

    setWorkspaceTab(tab) {
      this.workspaceTab = tab;
      this.closeFileContextMenu();
      if (tab === 'files' && !this.fileEntries.length) this.loadDirectory(this.fileDirectoryPath);
    },

    encodeBase64(value) {
      const bytes = new TextEncoder().encode(value);
      let binary = '';
      bytes.forEach((value) => { binary += String.fromCharCode(value); });
      return btoa(binary);
    },

    decodeBase64(value) {
      const binary = atob(String(value || '').replace(/\s/g, ''));
      return new TextDecoder().decode(Uint8Array.from(binary, (character) => character.charCodeAt(0)));
    },

    async runFileTask(action, arguments, risk = 'low', requiresApproval = false) {
      const queued = await this.createTask(action, arguments, risk, requiresApproval, { silent: true });
      if (!queued) return null;
      if (queued.status === 'awaiting_approval') {
        this.fileMessage = '删除任务已提交审批；批准后会在后台执行。';
        return null;
      }
      const completed = await this.waitForTask(queued.id);
      if (completed.status !== 'succeeded') {
        throw new Error(completed.output_summary || this.statusLabel(completed.status));
      }
      if (!completed.result_ref) return '';
      return this.api(completed.result_ref, { headers: {} });
    },

    parseFileListing(output) {
      if (String(output || '').trim().startsWith('[')) {
        const entries = JSON.parse(output);
        if (!Array.isArray(entries)) throw new Error('无效的目录结果');
        return entries.filter((entry) => typeof entry.name === 'string').map((entry) => ({
          kind: entry.directory ? 'd' : 'f', name: entry.name, modified: entry.mtime || '—',
          size: Number(entry.size || 0), permissions: '—', path: this.joinPath(this.fileDirectoryPath, entry.name),
        })).sort((left, right) => (left.kind !== right.kind ? (left.kind === 'd' ? -1 : 1) : left.name.localeCompare(right.name, 'zh-CN', { numeric: true })));
      }
      return String(output || '')
        .split(/\r?\n/)
        .filter(Boolean)
        .map((line) => {
          const [kind, name, modified, size, permissions] = line.split('\t');
          if (!name || !['d', 'f', 'l'].includes(kind)) return null;
          return {
            kind,
            name,
            modified: modified || '—',
            size: Number(size || 0),
            permissions: permissions || '—',
            path: this.joinPath(this.fileDirectoryPath, name),
          };
        })
        .filter(Boolean)
        .sort((left, right) => {
          if (left.kind !== right.kind) return left.kind === 'd' ? -1 : 1;
          return left.name.localeCompare(right.name, 'zh-CN', { numeric: true });
        });
    },

    async loadDirectory(path = this.fileDirectoryPath) {
      const nextPath = String(path || '').trim();
      if (!nextPath || this.fileLoading) return;
      this.fileLoading = true;
      this.fileMessage = '正在读取目录…';
      this.fileEditorOpen = false;
      this.closeFileContextMenu();
      try {
        const output = await this.runFileTask('list_files', { path: nextPath });
        if (output === null) return;
        this.fileDirectoryPath = nextPath;
        this.pathInput = nextPath;
        this.fileEntries = this.parseFileListing(output);
        this.selectedFilePath = '';
        this.fileMessage = this.fileEntries.length ? '' : '当前目录为空';
      } catch (error) {
        this.fileMessage = `目录读取失败：${error.message}`;
      } finally {
        this.fileLoading = false;
      }
    },

    joinPath(directory, name) {
      const windows = /\\/.test(directory) || /^[A-Za-z]:/.test(directory);
      const separator = windows ? '\\' : '/';
      const base = String(directory || separator).replace(/[\\/]+$/, '');
      return `${base || separator}${base ? separator : ''}${name}`.replace(windows ? /\\{2,}/g : /\/{2,}/g, separator);
    },

    parentPath(path = this.fileDirectoryPath) {
      const windows = /\\/.test(path) || /^[A-Za-z]:/.test(path);
      const separator = windows ? '\\' : '/';
      const value = String(path || separator).replace(/[\\/]+$/, '');
      if (!value || value === '/' || /^[A-Za-z]:$/.test(value)) return windows ? `${value}\\` : '/';
      const index = Math.max(value.lastIndexOf('/'), value.lastIndexOf('\\'));
      if (index <= 0) return windows ? value.slice(0, 2) + '\\' : '/';
      return value.slice(0, index);
    },

    fileTreeNodes() {
      const path = this.fileDirectoryPath;
      const windows = /\\/.test(path) || /^[A-Za-z]:/.test(path);
      const separator = windows ? '\\' : '/';
      const parts = path.split(/[\\/]/).filter(Boolean);
      const nodes = [];
      let current = windows && parts[0]?.endsWith(':') ? parts.shift() + '\\' : '/';
      nodes.push({ name: current, path: current });
      parts.forEach((part) => {
        current = this.joinPath(current, part);
        nodes.push({ name: part, path: current });
      });
      return nodes;
    },

    async openFileEntry(entry) {
      this.selectedFilePath = entry.path;
      this.closeFileContextMenu();
      if (entry.kind === 'd') {
        await this.loadDirectory(entry.path);
      } else {
        await this.readFileEntry(entry);
      }
    },

    async readFileEntry(entry) {
      this.fileLoading = true;
      this.fileMessage = `正在读取 ${entry.name}…`;
      try {
        const output = await this.runFileTask('read_file', { path: entry.path });
        if (output === null) return;
        this.fileContent = this.decodeBase64(output);
        this.fileEditorPath = entry.path;
        this.pathInput = entry.path;
        this.fileEditorOpen = true;
        this.fileMessage = '';
      } catch (error) {
        this.fileMessage = `文件读取失败：${error.message}`;
      } finally {
        this.fileLoading = false;
      }
    },

    async saveCurrentFile() {
      if (!this.fileEditorPath || this.fileLoading) return;
      this.fileLoading = true;
      try {
        await this.runFileTask('write_file', {
          path: this.fileEditorPath,
          content_base64: this.encodeBase64(this.fileContent || ''),
          overwrite: true,
        }, 'medium');
        this.fileMessage = '文件已保存';
        this.fileLoading = false;
        await this.loadDirectory(this.fileDirectoryPath);
      } catch (error) {
        this.fileMessage = `保存失败：${error.message}`;
      } finally {
        this.fileLoading = false;
      }
    },

    showFileContextMenu(event, entry) {
      event.preventDefault();
      this.selectedFilePath = entry.path;
      this.fileContextMenu = {
        open: true,
        x: Math.min(event.clientX, window.innerWidth - 190),
        y: Math.min(event.clientY, window.innerHeight - 260),
        entry,
      };
    },

    closeFileContextMenu() {
      this.fileContextMenu = { open: false, x: 0, y: 0, entry: null };
    },

    beginFileDialog(mode, entry = null) {
      this.closeFileContextMenu();
      this.fileDialog = {
        open: true,
        mode,
        entry,
        value: mode === 'rename' ? (entry?.name || '') : '',
      };
    },

    fileDialogTitle() {
      return { folder: '新建文件夹', file: '新建文件', rename: '重命名' }[this.fileDialog.mode] || '文件操作';
    },

    async confirmFileDialog() {
      const value = this.fileDialog.value.trim();
      if (!value || this.fileLoading) return;
      const { mode, entry } = this.fileDialog;
      this.fileDialog.open = false;
      try {
        if (mode === 'rename') {
          await this.runFileTask('move_file', {
            path: entry.path,
            destination: this.joinPath(this.fileDirectoryPath, value),
          }, 'medium');
        } else {
          await this.runFileTask(mode === 'folder' ? 'create_directory' : 'create_file', {
            path: this.joinPath(this.fileDirectoryPath, value),
          });
        }
        this.fileMessage = '操作已完成';
        await this.loadDirectory(this.fileDirectoryPath);
      } catch (error) {
        this.fileMessage = `操作失败：${error.message}`;
      }
    },

    async deleteFileEntry(entry) {
      this.closeFileContextMenu();
      await this.runFileTask('delete_file', { path: entry.path }, 'high', true);
    },

    async downloadFile(entry) {
      this.closeFileContextMenu();
      try {
        const output = await this.runFileTask('read_file', { path: entry.path });
        if (output === null) return;
        const bytes = Uint8Array.from(atob(String(output).replace(/\s/g, '')), (character) => character.charCodeAt(0));
        const link = document.createElement('a');
        link.href = URL.createObjectURL(new Blob([bytes]));
        link.download = entry.name;
        link.click();
        URL.revokeObjectURL(link.href);
      } catch (error) {
        this.fileMessage = `下载失败：${error.message}`;
      }
    },

    async uploadFile(event) {
      const file = event.target.files?.[0];
      event.target.value = '';
      if (!file) return;
      try {
        const buffer = new Uint8Array(await file.arrayBuffer());
        let binary = '';
        buffer.forEach((value) => { binary += String.fromCharCode(value); });
        await this.runFileTask('write_file', {
          path: this.joinPath(this.fileDirectoryPath, file.name),
          content_base64: btoa(binary),
        }, 'medium');
        this.fileMessage = `${file.name} 已上传`;
        await this.loadDirectory(this.fileDirectoryPath);
      } catch (error) {
        this.fileMessage = `上传失败：${error.message}`;
      }
    },

    openDirectoryInTerminal(path = this.fileDirectoryPath) {
      this.terminalIdentity.cwd = path;
      this.workspaceTab = 'terminal';
      this.closeFileContextMenu();
    },

    formatFileSize(bytes) {
      const value = Number(bytes || 0);
      if (value < 1024) return `${value} B`;
      if (value < 1024 * 1024) return `${(value / 1024).toFixed(value < 10240 ? 1 : 0)} KB`;
      return `${(value / (1024 * 1024)).toFixed(1)} MB`;
    },

    async runDatabaseQuery() {
      const query = String(this.databaseQuery || '').trim();
      if (!query) return;
      let command = '';
      if (this.databaseType === 'sqlite') {
        if (!this.databaseName.trim()) {
          this.error = 'SQLite 查询需要填写数据库文件路径';
          return;
        }
        command = `sqlite3 ${JSON.stringify(this.databaseName.trim())} ${JSON.stringify(query)}`;
      } else if (this.databaseType === 'postgresql') {
        command = `psql -h ${JSON.stringify(this.databaseHost)} -p ${Number(this.databasePort || 5432)} ${this.databaseName ? `-d ${JSON.stringify(this.databaseName)}` : ''} -c ${JSON.stringify(query)}`;
      } else {
        command = `mysql -h ${JSON.stringify(this.databaseHost)} -P ${Number(this.databasePort || 3306)} ${this.databaseName ? JSON.stringify(this.databaseName) : ''} -e ${JSON.stringify(query)}`;
      }
      await this.runQuickCommand(command.trim());
    },

    async testWebshellForm() {
      const form = this.createForm;
      if (!this.projectId() || !String(form.target || '').trim()) {
        this.testMessage = '请先填写 Shell 地址';
        return;
      }
      this.testBusy = true;
      this.testMessage = '正在测试连接…';
      try {
        const data = await this.api(`/projects/${encodeURIComponent(this.projectId())}/webshell/test`, {
          method: 'POST',
          body: JSON.stringify({
            target: form.target.trim(),
            password: form.password || '',
            shell_type: form.shellType,
            protocol: form.protocol,
            method: form.method,
            command_param: form.commandParam || '',
            password_param: form.passwordParam || '',
            target_os: form.targetOs,
            encoding: form.encoding,
            verify_tls: Boolean(form.verifyTls),
          }),
        });
        this.testMessage = `连接成功：${data.summary || '探测通过'}`;
      } catch (error) {
        this.testMessage = error.message;
      } finally {
        this.testBusy = false;
      }
    },

    async batchProbe() {
      const webshells = this.resources.filter((item) => item.kind === 'webshell');
      for (const item of webshells) {
        this.selectedResourceId = item.id;
        await this.selectResource(item.id);
        const task = await this.createTask('probe', {}, 'low', false);
        if (task) {
          try { await this.waitForTask(task.id, 25000); } catch (_) {}
        }
      }
      await this.refresh(false);
    },

    c2Listeners() {
      return this.resources.filter((item) => item.kind === 'c2_listener');
    },

    c2Profiles() {
      return this.resources.filter((item) => item.kind === 'c2_profile');
    },

    payloads() {
      return this.filteredResources();
    },

    payloadFiles() {
      return this.payloads().filter((item) => item.metadata?.payload_type !== 'command').length;
    },

    payloadCommands() {
      return this.payloads().filter((item) => item.metadata?.payload_type === 'command').length;
    },

    payloadSourceLabel(item) {
      if (item.metadata?.source_type === 'worker' || item.created_by_type === 'worker') return `Worker · ${item.worker || item.created_by || 'unknown'}`;
      if (item.metadata?.source_type === 'upload') return '人工上传';
      return item.metadata?.external ? '外部 C2' : 'Payload 生成器';
    },

    payloadListenerName(item) {
      const id = item.metadata?.listener_id;
      return this.c2Listeners().find((listener) => listener.id === id)?.name || (id ? id : '未绑定');
    },

    payloadFormat(item) {
      return [item.metadata?.platform, item.metadata?.arch, item.metadata?.format]
        .filter((value) => value && value !== 'unknown').join(' · ') || (item.metadata?.payload_type === 'command' ? '单行命令' : '文件');
    },

    payloadBusy() {
      return this.payloadGenerating || this.payloadBuilding || this.externalPayloadBuilding || this.payloadUploadBusy;
    },

    openPayloadCreate(mode) {
      this.payloadMenuOpen = false;
      this.payloadDialogMode = mode;
      this.error = '';
      if (mode === 'upload') {
        this.payloadUploadFile = null;
        this.payloadUploadName = '';
        this.payloadUploadSummary = '';
      }
    },

    closePayloadCreate() {
      if (!this.payloadBusy()) this.payloadDialogMode = '';
    },

    choosePayloadFile(event) {
      this.payloadUploadFile = event.target.files?.[0] || null;
      if (this.payloadUploadFile && !this.payloadUploadName) this.payloadUploadName = this.payloadUploadFile.name;
    },

    async copyPayload(item) {
      try {
        const { command } = await this.api(`/projects/${encodeURIComponent(this.projectId())}/resources/${encodeURIComponent(item.id)}/material`, { method: 'POST' });
        await navigator.clipboard.writeText(command);
        this.payloadCopiedId = item.id;
        window.setTimeout(() => { if (this.payloadCopiedId === item.id) this.payloadCopiedId = ''; }, 1400);
      } catch (error) { this.error = `复制失败：${error.message}`; }
    },

    async removePayload(item) {
      await this.selectResource(item.id);
      await this.removeResource();
    },

    async generateOneliner() {
      if (!this.payloadListenerId || this.payloadGenerating) {
        this.error = '请先选择监听器';
        return;
      }
      this.payloadGenerating = true;
      try {
        const data = await this.api(`/projects/${encodeURIComponent(this.projectId())}/c2/payloads/oneliner`, {
          method: 'POST',
          body: JSON.stringify({
            listener_id: this.payloadListenerId,
            kind: this.payloadKind,
            callback_host: this.payloadCallback || '',
          }),
        });
        this.payloadOneliner = data.oneliner;
        this.payloadDialogMode = '';
        this.selectedResourceId = data.payload.id;
        await this.refresh(false);
      } catch (error) {
        this.error = error.message;
      } finally {
        this.payloadGenerating = false;
      }
    },

    async buildBeacon() {
      if (!this.payloadListenerId || this.payloadBuilding) return;
      this.payloadBuilding = true;
      this.builtPayload = null;
      try {
        const callbackUrl = this.payloadCallback && this.payloadCallback.includes('://') ? this.payloadCallback : '';
        const data = await this.api(`/projects/${encodeURIComponent(this.projectId())}/c2/payloads/build`, {
          method: 'POST',
          body: JSON.stringify({
            listener_id: this.payloadListenerId,
            callback_url: callbackUrl,
            os: this.payloadOs,
            arch: this.payloadArch,
            actor: this.actorName(),
          }),
        });
        this.builtPayload = data.payload;
        this.payloadDialogMode = '';
        this.selectedResourceId = data.payload.id;
        await this.refresh(false);
      } catch (error) {
        this.error = error.message;
      } finally {
        this.payloadBuilding = false;
      }
    },

    async buildExternalPayload() {
      if (!this.payloadListenerId || this.externalPayloadBuilding) return;
      let options = {};
      try { options = JSON.parse(this.externalPayloadOptions || '{}'); }
      catch (_) { this.error = '外部 Payload 参数必须是有效 JSON'; return; }
      this.externalPayloadBuilding = true;
      this.builtPayload = null;
      try {
        const data = await this.api(`/projects/${encodeURIComponent(this.projectId())}/c2/payloads/external`, {
          method: 'POST',
          body: JSON.stringify({
            listener_id: this.payloadListenerId,
            format: this.externalPayloadFormat || 'default',
            options,
            actor: this.actorName(),
          }),
        });
        this.builtPayload = data.payload;
        this.payloadDialogMode = '';
        this.selectedResourceId = data.payload.id;
        await this.refresh(false);
      } catch (error) { this.error = error.message; }
      finally { this.externalPayloadBuilding = false; }
    },

    async uploadPayload() {
      const file = this.payloadUploadFile;
      if (!file || this.payloadUploadBusy) return;
      this.payloadUploadBusy = true;
      try {
        const params = new URLSearchParams({
          filename: file.name,
          name: this.payloadUploadName || file.name,
          platform: this.payloadOs,
          arch: this.payloadArch,
          listener_id: this.payloadListenerId || '',
          summary: this.payloadUploadSummary || '',
        });
        const data = await this.api(`/projects/${encodeURIComponent(this.projectId())}/c2/payloads/upload?${params}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/octet-stream' },
          body: file,
        });
        this.payloadDialogMode = '';
        this.selectedResourceId = data.payload.id;
        await this.refresh(false);
      } catch (error) {
        this.error = error.message;
      } finally {
        this.payloadUploadBusy = false;
      }
    },

    async loadResult(task) {
      if (!task?.result_ref || this.resultLoading) return;
      this.resultLoading = true;
      try {
        this.terminalOutput = await this.api(task.result_ref, { headers: {} });
      } catch (error) {
        this.error = error.message;
      } finally {
        this.resultLoading = false;
      }
    },

    async decideTask(task, decision) {
      await this.api(
        `/projects/${encodeURIComponent(this.projectId())}/operations/tasks/${encodeURIComponent(task.id)}/approval`,
        {
          method: 'POST',
          body: JSON.stringify({ actor: this.actorName(), decision }),
        }
      );
      await this.refresh(false);
      if (this.selectedResourceId) await this.selectResource(this.selectedResourceId);
    },

    async cancelTask(task) {
      await this.api(
        `/projects/${encodeURIComponent(this.projectId())}/operations/tasks/${encodeURIComponent(task.id)}/cancel`,
        {
          method: 'POST',
          body: JSON.stringify({ actor: this.actorName(), reason: '人工取消' }),
        }
      );
      await this.refresh(false);
    },

    async deleteTask(task) {
      if (!await window.redtraceConfirm?.({
        title: '删除 C2 任务',
        description: '任务记录及其结果引用将被移除，事件时间线中的历史记录保持不变。',
        subject: `${task.action} · ${task.id}`,
        note: '此操作不可撤销。',
        confirmLabel: '删除任务',
      })) return;
      try {
        await this.api(
          `/projects/${encodeURIComponent(this.projectId())}/operations/tasks/${encodeURIComponent(task.id)}`,
          { method: 'DELETE' }
        );
        await this.refresh(false);
      } catch (error) {
        this.error = error.message;
      }
    },

    async clearC2Tasks() {
      const deletable = this.c2TaskCount(['succeeded', 'failed', 'cancelled', 'rejected']);
      if (!deletable) return;
      if (!await window.redtraceConfirm?.({
        title: '清空 C2 任务记录',
        description: `将删除 ${deletable} 条已结束的任务及其结果引用，执行中或待审批的任务会被保留。`,
        subject: 'C2 任务队列',
        note: '此操作不可撤销。',
        confirmLabel: '清空任务',
      })) return;
      try {
        await this.api(
          `/projects/${encodeURIComponent(this.projectId())}/operations/tasks`,
          { method: 'DELETE' }
        );
        await this.refresh(false);
      } catch (error) {
        this.error = error.message;
      }
    },

    async deleteEvent(event) {
      if (!await window.redtraceConfirm?.({
        title: '删除 C2 事件',
        description: '该事件将从时间线中移除，其余记录不受影响。',
        subject: `${event.action} · ${this.relativeTime(event.created_at)}`,
        note: '此操作不可撤销。',
        confirmLabel: '删除事件',
      })) return;
      try {
        await this.api(
          `/projects/${encodeURIComponent(this.projectId())}/operations/audit/${encodeURIComponent(event.id)}`,
          { method: 'DELETE' }
        );
        await this.refresh(false);
      } catch (error) {
        this.error = error.message;
      }
    },

    async clearC2Events() {
      const total = this.c2EventCount();
      if (!total) return;
      if (!await window.redtraceConfirm?.({
        title: '清空 C2 事件记录',
        description: `将删除 ${total} 条 C2 相关事件，其他资源与操作的审计记录保持不变。`,
        subject: 'C2 事件时间线',
        note: '此操作不可撤销。',
        confirmLabel: '清空事件',
      })) return;
      try {
        await this.api(
          `/projects/${encodeURIComponent(this.projectId())}/operations/audit`,
          { method: 'DELETE' }
        );
        await this.refresh(false);
      } catch (error) {
        this.error = error.message;
      }
    },

    async toggleLock() {
      const resource = this.currentResource();
      if (!resource) return;
      const action = resource.locked ? 'unlock' : 'lock';
      const data = await this.api(
        `/projects/${encodeURIComponent(this.projectId())}/resources/${encodeURIComponent(resource.id)}/${action}`,
        {
          method: 'POST',
          body: JSON.stringify({ actor_type: 'human', actor: this.actorName() }),
        }
      );
      this.detail.resource = data.resource;
      await this.refresh(false);
    },

    async toggleWorkerPause() {
      const resource = this.currentResource();
      if (!resource) return;
      const data = await this.api(
        `/projects/${encodeURIComponent(this.projectId())}/resources/${encodeURIComponent(resource.id)}/worker-control`,
        {
          method: 'POST',
          body: JSON.stringify({ paused: !resource.worker_paused, actor: this.actorName() }),
        }
      );
      this.detail.resource = data.resource;
      await this.refresh(false);
    },

    async setState(status) {
      const resource = this.currentResource();
      if (!resource) return;
      const data = await this.api(
        `/projects/${encodeURIComponent(this.projectId())}/resources/${encodeURIComponent(resource.id)}/state`,
        {
          method: 'POST',
          body: JSON.stringify({ status, actor: this.actorName() }),
        }
      );
      this.detail.resource = data.resource;
      await this.refresh(false);
    },

    async removeResource() {
      const resource = this.currentResource();
      if (!resource || !await window.redtraceConfirm?.({
        title: `删除 ${this.kindLabel(resource.kind)}`,
        description: '对象将从管理页面移除，工作台图谱中的对应节点也会同步清理。',
        subject: resource.name,
        note: '此操作不可撤销。',
        confirmLabel: '删除对象',
      })) return;
      await this.api(
        `/projects/${encodeURIComponent(this.projectId())}/resources/${encodeURIComponent(resource.id)}?actor=${encodeURIComponent(this.actorName())}`,
        { method: 'DELETE' }
      );
      this.selectedResourceId = '';
      this.detail = null;
      await this.refresh(false);
    },

    async copySecret() {
      if (!this.secretOnce) return;
      await navigator.clipboard.writeText(this.secretOnce);
    },
  };
}
