import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, rmSync } from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { Configuration, serveEngine } from '../src/index.ts'

test('HTTP graph compatibility and atomic conclude survive reopening the database', async () => {
  const root = mkdtempSync(path.join(os.tmpdir(), 'redtrace-api-'))
  let engine = await serveEngine({ root, port: 0, autoStart: false })
  const request = async (pathname: string, method = 'GET', body?: unknown) => {
    const address = engine.server.address() as { port: number }
    const response = await fetch(`http://127.0.0.1:${address.port}${pathname}`, { method, ...(body === undefined ? {} : { headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }) })
    return { status: response.status, data: response.status === 204 ? null : await response.json() as any }
  }
  try {
    assert.equal((await request('/projects', 'POST', { title: '' })).status, 422)
    const created = await request('/projects', 'POST', { title: 'Test', origin: 'Input', goal: 'Verified result' })
    assert.equal(created.status, 201); const id = created.data.project.id, base = `/projects/${id}`
    const step = await request(`${base}/intents`, 'POST', { from: ['origin'], description: 'Check input', creator: 'human' })
    assert.equal(step.status, 201)
    engine.store.claim(id, 'execute', { name: 'w1', backend: 'dsh' }, step.data.id)
    assert.equal((await request(`${base}/intents/${step.data.id}/conclude`, 'POST', { worker: 'w2', description: 'Invalid owner' })).status, 409)
    assert.equal((await request(base)).data.facts.length, 2)
    const concluded = await request(`${base}/intents/${step.data.id}/conclude`, 'POST', { worker: 'w1', description: 'Input checked' })
    assert.equal(concluded.status, 200); assert.equal(concluded.data.intent.to, concluded.data.fact.id)
    assert.equal((await request(`${base}/complete`, 'POST', { from: [concluded.data.fact.id], description: 'Result verified', worker: 'w1' })).data.to, 'goal')
    assert.equal((await request(`${base}/hints`, 'POST', { content: 'Review later', creator: 'human' })).status, 201)
    const beforeReopen = engine.store.graph(id), runsBeforeReopen = engine.store.runs(id).length
    const reopened = await request(`${base}/reopen`, 'POST', { description: 'One more check', creator: 'human' })
    assert.equal(reopened.status, 200); assert.equal(reopened.data.hint.content, 'One more check')
    assert.equal(reopened.data.fact, undefined); assert.equal(reopened.data.intent, undefined)
    assert.equal(engine.store.graph(id).facts.length, beforeReopen.facts.length)
    assert.equal(engine.store.graph(id).steps.length, beforeReopen.steps.length)
    assert.equal(engine.store.runs(id).length, runsBeforeReopen)
    assert.equal(engine.store.project(id).status, 'active')
    assert.equal(engine.store.graph(id).goals[0].status, 'open')
    const graph = (await request(`/v2${base}/graph`)).data
    assert.equal(graph.goals[0].kind, 'goal'); assert.equal(graph.facts.some((f: any) => f.id === 'goal'), false)
    const replayed = await request(`/v2${base}/graph?revision=${graph.project.revision}`)
    assert.equal(replayed.status, 422); assert.match(replayed.data.detail, /history has been removed/)
    assert.ok(graph.nodes.every((n: any) => ['scope', 'fact', 'finding', 'subgoal', 'goal'].includes(n.nodeType)))
    assert.equal((await request(`/v2${base}/graph?revision=1`)).status, 422)
    assert.equal((await request(`/v2${base}/graph?includeInactive=true`)).status, 422)
    assert.equal((await request(`/v2${base}/facts?includeInactive=false`)).status, 422)
    for (const operation of ['archive', 'restore']) {
      const old = await request(`/v2${base}/evidence/manage`, 'POST', { operation, id: concluded.data.fact.id, expectedVersion: 1, reason: 'Old client' })
      assert.equal(old.status, 422); assert.match(old.data.detail, /archive\/restore has been removed/)
    }
    assert.equal((await request(`/v2${base}/graph?revision=999999`)).status, 422)
    const runs = (await request(`/v2${base}/steps/${step.data.id}/runs`)).data
    assert.equal(runs.length, 1)
    engine.store.runEvent(runs[0].id, 'assistant.message', { content: 'Traceable execution' })
    const logs = (await request(`/v2${base}/runs/${runs[0].id}/events`)).data
    assert.ok(logs.some((event: any) => JSON.stringify(event).includes('Traceable execution')))
    const other = (await request('/v2/projects', 'POST', { title: 'Other', origin: 'Other scope', goal: 'Other goal' })).data.project.id
    assert.equal((await request(`/v2/projects/${other}/runs/${runs[0].id}/events`)).status, 404)
    await engine.close(); engine = await serveEngine({ root, port: 0, autoStart: false })
    assert.deepEqual((await request(`/v2${base}/graph`)).data, graph)
  } finally { await engine.close(); rmSync(root, { recursive: true, force: true }) }
})

test('standalone mock executes an explicit Soldier Mission but never impersonates Commander acceptance',async()=>{const root=mkdtempSync(path.join(os.tmpdir(),'redtrace-loop-')),config=new Configuration(root);config.initialize();config.commit(config.read().revision,raw=>{raw.workers=[{name:'mock',provider:'mock',roles:['soldier'],max_running:4}]});const engine=await serveEngine({root,port:0});try{const p=engine.store.createProject({title:'Mock',origin:'Fixture',goal:'Verified output',bootstrap:true}).project;for(let i=0;i<200&&!engine.store.runs(p.id).some(r=>r.status==='succeeded');i++)await new Promise(r=>setTimeout(r,10));const graph=engine.store.graph(p.id);assert.equal(graph.project.status,'active');assert.equal(graph.steps[0].role,'soldier');assert.equal(graph.findings.length,1);assert.equal(graph.goals[0].status,'open');assert.ok(engine.store.runs(p.id).every(r=>r.activity==='execute'&&r.status==='succeeded'))}finally{await engine.close();rmSync(root,{recursive:true,force:true})}})

